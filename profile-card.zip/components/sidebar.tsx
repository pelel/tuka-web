"use client"

import { Instagram, Linkedin, Camera, Tag, BookOpen, Film } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

export function Sidebar() {
  return (
    <aside className="lg:w-1/4 bg-muted/30 p-4 rounded-lg">
      <div className="flex flex-col space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">Portfolio</h3>
          <div className="flex space-x-2">
            <a href="#" aria-label="Instagram">
              <Button variant="ghost" size="icon" className="rounded-full">
                <Instagram className="h-5 w-5" />
              </Button>
            </a>
            <a href="#" aria-label="LinkedIn">
              <Button variant="ghost" size="icon" className="rounded-full">
                <Linkedin className="h-5 w-5" />
              </Button>
            </a>
          </div>
        </div>

        <Collapsible defaultOpen>
          <CollapsibleTrigger className="flex items-center justify-between w-full text-left font-medium">
            <div className="flex items-center">
              <Camera className="mr-2 h-4 w-4" />
              <span>CAMERAS</span>
            </div>
          </CollapsibleTrigger>
          <CollapsibleContent className="pl-6 mt-2 space-y-1">
            {["FUJIFILM X-T5", "FUJIFILM X-T1", "IPHONE 15 PRO", "IPHONE 13 PRO"].map((camera) => (
              <div key={camera} className="text-sm py-1 hover:text-primary cursor-pointer">
                {camera}
              </div>
            ))}
          </CollapsibleContent>
        </Collapsible>

        <Collapsible defaultOpen>
          <CollapsibleTrigger className="flex items-center justify-between w-full text-left font-medium">
            <div className="flex items-center">
              <Tag className="mr-2 h-4 w-4" />
              <span>TAGS</span>
            </div>
          </CollapsibleTrigger>
          <CollapsibleContent className="pl-6 mt-2 space-y-1">
            {["FAVS ⭐", "LBK", "KROLLS", "LIGHTS", "FARM"].map((tag) => (
              <div key={tag} className="text-sm py-1 hover:text-primary cursor-pointer">
                {tag}
              </div>
            ))}
            <div className="text-sm py-1 text-muted-foreground cursor-pointer">MORE ↓</div>
          </CollapsibleContent>
        </Collapsible>

        <Collapsible defaultOpen>
          <CollapsibleTrigger className="flex items-center justify-between w-full text-left font-medium">
            <div className="flex items-center">
              <BookOpen className="mr-2 h-4 w-4" />
              <span>RECIPES</span>
            </div>
          </CollapsibleTrigger>
          <CollapsibleContent className="pl-6 mt-2 space-y-1">
            {["PACIFIC BLUE", "ARIZONA", "NURTURE NATURE", "SUPERIA 800", "CLASSIC CUBAN"].map((recipe) => (
              <div key={recipe} className="text-sm py-1 hover:text-primary cursor-pointer">
                {recipe}
              </div>
            ))}
          </CollapsibleContent>
        </Collapsible>

        <Collapsible defaultOpen>
          <CollapsibleTrigger className="flex items-center justify-between w-full text-left font-medium">
            <div className="flex items-center">
              <Film className="mr-2 h-4 w-4" />
              <span>FILMS</span>
            </div>
          </CollapsibleTrigger>
          <CollapsibleContent className="pl-6 mt-2 space-y-1">
            {["PROVIA/STD", "CLASSIC NEG.", "NOSTALGIC NEG.", "ACROS", "VELVIA/VIVID"].map((film) => (
              <div key={film} className="text-sm py-1 hover:text-primary cursor-pointer">
                {film}
              </div>
            ))}
            <div className="text-sm py-1 text-muted-foreground cursor-pointer">MORE ↓</div>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </aside>
  )
}
