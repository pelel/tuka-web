"use client"

import { useState } from "react"
import { LayoutGrid, LayoutList, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Sidebar } from "@/components/sidebar"
import { InfiniteGallery } from "@/components/portfolio/infinite-gallery"
import { useSession } from "next-auth/react"
import Link from "next/link"

interface MediaItem {
  id: string
  type: "image" | "video"
  title: string
  url: string
  thumbnailUrl?: string
  tags: { name: string }[]
}

interface PortfolioSectionProps {
  initialItems?: MediaItem[]
}

export default function PortfolioSection({ initialItems = [] }: PortfolioSectionProps) {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [activeTag, setActiveTag] = useState<string | undefined>(undefined)
  const { data: session } = useSession()

  return (
    <section className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">My Portfolio</h2>
              <div className="flex items-center gap-4">
                <div className="flex border rounded-md overflow-hidden">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("grid")}
                    aria-label="Grid view"
                  >
                    <LayoutGrid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("list")}
                    aria-label="List view"
                  >
                    <LayoutList className="h-4 w-4" />
                  </Button>
                </div>
                <Tabs defaultValue="all" onValueChange={(value) => setActiveTag(value === "all" ? undefined : value)}>
                  <TabsList>
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="nature">Nature</TabsTrigger>
                    <TabsTrigger value="urban">Urban</TabsTrigger>
                    <TabsTrigger value="portrait">Portrait</TabsTrigger>
                  </TabsList>
                </Tabs>
                {session && (
                  <Button asChild size="sm">
                    <Link href="/upload">Upload</Link>
                  </Button>
                )}
                <Button variant="outline" size="icon">
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <InfiniteGallery initialItems={initialItems} viewMode={viewMode} tag={activeTag} />
          </div>

          <Sidebar />
        </div>
      </div>
    </section>
  )
}
