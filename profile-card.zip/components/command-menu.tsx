"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command"
import { ImageIcon, Search, Upload, User, Home, Settings } from "lucide-react"
import { LucideTag } from "lucide-react"

// Sample data for search results
const samplePhotos = [
  { id: "1", title: "Spring Flowers", type: "image" },
  { id: "2", title: "Fire Hydrant", type: "image" },
  { id: "3", title: "Green Leaves", type: "image" },
  { id: "4", title: "Meteor Shower", type: "image" },
  { id: "5", title: "Water Splash Video", type: "video" },
]

const sampleTags = [
  { name: "nature", count: 8 },
  { name: "urban", count: 3 },
  { name: "portrait", count: 2 },
  { name: "macro", count: 4 },
  { name: "night", count: 2 },
]

interface Photo {
  id: string
  title: string
  type: string
}

interface TagType {
  name: string
  count: number
}

export function CommandMenu() {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState("")
  const [photos, setPhotos] = useState<Photo[]>([])
  const [tags, setTags] = useState<TagType[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setOpen((open) => !open)
      }
    }

    document.addEventListener("keydown", down)
    return () => document.removeEventListener("keydown", down)
  }, [])

  useEffect(() => {
    if (!open || !search) {
      setPhotos([])
      setTags([])
      return
    }

    const fetchResults = async () => {
      setLoading(true)
      try {
        // Simulate API call with a delay
        await new Promise((resolve) => setTimeout(resolve, 300))

        // Filter sample data based on search term
        const filteredPhotos = samplePhotos.filter((photo) => photo.title.toLowerCase().includes(search.toLowerCase()))

        const filteredTags = sampleTags.filter((tag) => tag.name.toLowerCase().includes(search.toLowerCase()))

        setPhotos(filteredPhotos)
        setTags(filteredTags)
      } catch (error) {
        console.error("Search error:", error)
      } finally {
        setLoading(false)
      }
    }

    const debounce = setTimeout(fetchResults, 300)
    return () => clearTimeout(debounce)
  }, [search, open])

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search photos, tags, or navigate..." value={search} onValueChange={setSearch} />
      <CommandList>
        <CommandEmpty>{loading ? "Searching..." : "No results found."}</CommandEmpty>

        {photos.length > 0 && (
          <CommandGroup heading="Photos">
            {photos.map((photo) => (
              <CommandItem
                key={photo.id}
                onSelect={() => {
                  router.push(`/photos/${photo.id}`)
                  setOpen(false)
                }}
              >
                {photo.type === "image" ? (
                  <ImageIcon className="mr-2 h-4 w-4" />
                ) : (
                  <ImageIcon className="mr-2 h-4 w-4" />
                )}
                {photo.title}
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        {tags.length > 0 && (
          <CommandGroup heading="Tags">
            {tags.map((tag) => (
              <CommandItem
                key={tag.name}
                onSelect={() => {
                  router.push(`/tags/${tag.name}`)
                  setOpen(false)
                }}
              >
                <LucideTag className="mr-2 h-4 w-4" />
                {tag.name} ({tag.count})
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        <CommandSeparator />

        <CommandGroup heading="Navigation">
          <CommandItem
            onSelect={() => {
              router.push("/")
              setOpen(false)
            }}
          >
            <Home className="mr-2 h-4 w-4" />
            Home
          </CommandItem>
          <CommandItem
            onSelect={() => {
              router.push("/dashboard")
              setOpen(false)
            }}
          >
            <User className="mr-2 h-4 w-4" />
            Dashboard
          </CommandItem>
          <CommandItem
            onSelect={() => {
              router.push("/upload")
              setOpen(false)
            }}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </CommandItem>
          <CommandItem
            onSelect={() => {
              router.push("/search")
              setOpen(false)
            }}
          >
            <Search className="mr-2 h-4 w-4" />
            Advanced Search
          </CommandItem>
          <CommandItem
            onSelect={() => {
              router.push("/settings")
              setOpen(false)
            }}
          >
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
