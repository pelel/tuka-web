"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { useInView } from "react-intersection-observer"
import { MediaCard } from "@/components/media-card"
import { Loader2 } from "lucide-react"

// Sample data for the gallery (will be replaced with real data later)
const sampleMedia = [
  {
    id: "1",
    type: "image",
    title: "Spring Flowers",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "2",
    type: "image",
    title: "Fire Hydrant",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "urban" }],
  },
  {
    id: "3",
    type: "image",
    title: "Green Leaves",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "4",
    type: "image",
    title: "Meteor Shower",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "night" }],
  },
  {
    id: "5",
    type: "image",
    title: "Dandelions",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "6",
    type: "image",
    title: "Red Flower",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "7",
    type: "video",
    title: "Water Splash",
    url: "/placeholder.mp4",
    thumbnailUrl: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "water" }],
  },
  {
    id: "8",
    type: "image",
    title: "Water Droplets",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "macro" }],
  },
  {
    id: "9",
    type: "video",
    title: "Nature Video",
    url: "/placeholder.mp4",
    thumbnailUrl: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "10",
    type: "image",
    title: "Pink Roses",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "flowers" }],
  },
  {
    id: "11",
    type: "image",
    title: "Green Plants",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "12",
    type: "image",
    title: "Sunset Street",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "urban" }],
  },
]

interface MediaItem {
  id: string
  type: "image" | "video"
  title: string
  url: string
  thumbnailUrl?: string
  tags: { name: string }[]
}

interface InfiniteGalleryProps {
  initialItems?: MediaItem[]
  viewMode: "grid" | "list"
  tag?: string
}

export function InfiniteGallery({ initialItems = sampleMedia, viewMode, tag }: InfiniteGalleryProps) {
  const [items, setItems] = useState<MediaItem[]>(initialItems)
  const [isLoading, setIsLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const page = useRef(1)

  const { ref, inView } = useInView({
    threshold: 0,
    rootMargin: "200px",
  })

  const loadMoreItems = useCallback(async () => {
    if (isLoading || !hasMore) return

    setIsLoading(true)
    try {
      // Simulate API call with a delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Filter by tag if provided
      let newItems = [...sampleMedia]
      if (tag) {
        newItems = newItems.filter((item) => item.tags.some((t) => t.name.toLowerCase() === tag.toLowerCase()))
      }

      // Simulate pagination
      const nextPage = page.current + 1
      const startIndex = page.current * 12
      const endIndex = startIndex + 12
      const nextItems = newItems.slice(startIndex, endIndex)

      if (nextItems.length === 0) {
        setHasMore(false)
      } else {
        // Add random IDs to make them unique from the initial set
        const itemsWithUniqueIds = nextItems.map((item) => ({
          ...item,
          id: `${item.id}-${nextPage}-${Math.random().toString(36).substring(2, 9)}`,
        }))

        setItems((prev) => [...prev, ...itemsWithUniqueIds])
        page.current = nextPage
      }
    } catch (error) {
      console.error("Error loading more items:", error)
    } finally {
      setIsLoading(false)
    }
  }, [isLoading, hasMore, tag])

  useEffect(() => {
    if (inView) {
      loadMoreItems()
    }
  }, [inView, loadMoreItems])

  // Reset when tag changes
  useEffect(() => {
    // Filter initial items by tag
    let filteredItems = [...initialItems]
    if (tag) {
      filteredItems = filteredItems.filter((item) => item.tags.some((t) => t.name.toLowerCase() === tag.toLowerCase()))
    }

    setItems(filteredItems)
    page.current = 1
    setHasMore(true)
  }, [initialItems, tag])

  return (
    <div className="space-y-6">
      <div
        className={`grid gap-4 ${
          viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4" : "grid-cols-1"
        }`}
      >
        {items.map((item) => (
          <MediaCard
            key={item.id}
            item={{
              id: Number.parseInt(item.id),
              type: item.type,
              src: item.url,
              thumbnail: item.thumbnailUrl,
              title: item.title,
            }}
            viewMode={viewMode}
          />
        ))}
      </div>

      {hasMore && (
        <div ref={ref} className="flex justify-center py-4">
          {isLoading && (
            <div className="flex items-center">
              <Loader2 className="h-6 w-6 animate-spin mr-2" />
              <span>Loading more...</span>
            </div>
          )}
        </div>
      )}

      {!hasMore && items.length > 0 && (
        <div className="text-center py-4 text-muted-foreground">No more photos to load</div>
      )}

      {!hasMore && items.length === 0 && (
        <div className="text-center py-12">
          <p className="text-xl font-medium">No photos found</p>
          <p className="text-muted-foreground mt-2">
            {tag ? `No photos with tag "${tag}"` : "Upload some photos to get started"}
          </p>
        </div>
      )}
    </div>
  )
}
