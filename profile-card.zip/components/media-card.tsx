"use client"

import { useState } from "react"
import { Card, CardFooter } from "@/components/ui/card"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Play } from "lucide-react"

interface MediaItem {
  id: number
  type: "image" | "video"
  src: string
  thumbnail?: string
  title: string
}

interface MediaCardProps {
  item: MediaItem
  viewMode: "grid" | "list"
}

export function MediaCard({ item, viewMode }: MediaCardProps) {
  const [isPlaying, setIsPlaying] = useState(false)

  const handleVideoEnd = () => {
    setIsPlaying(false)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card
          className={`overflow-hidden cursor-pointer hover:shadow-lg transition-shadow ${
            viewMode === "list" ? "flex items-center" : ""
          }`}
        >
          <div className={`relative ${viewMode === "list" ? "w-40 h-24 flex-shrink-0" : "w-full aspect-square"}`}>
            {item.type === "image" ? (
              <img src={item.src || "/placeholder.svg"} alt={item.title} className="w-full h-full object-cover" />
            ) : (
              <div className="relative w-full h-full">
                <img
                  src={item.thumbnail || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                  <Play className="w-12 h-12 text-white" />
                </div>
              </div>
            )}
          </div>
          <CardFooter className={`p-2 ${viewMode === "list" ? "flex-1" : ""}`}>
            <p className="text-sm font-medium truncate w-full">{item.title}</p>
          </CardFooter>
        </Card>
      </DialogTrigger>
      <DialogContent className="max-w-4xl">
        {item.type === "image" ? (
          <div className="w-full">
            <img src={item.src || "/placeholder.svg"} alt={item.title} className="w-full h-auto" />
            <p className="mt-2 text-center font-medium">{item.title}</p>
          </div>
        ) : (
          <div className="w-full">
            <video
              src={item.src}
              controls
              autoPlay={isPlaying}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onEnded={handleVideoEnd}
              className="w-full h-auto"
            >
              Your browser does not support the video tag.
            </video>
            <p className="mt-2 text-center font-medium">{item.title}</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
