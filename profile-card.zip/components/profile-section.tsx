"use client"

import { Linkedin, Github, FileText, Instagram } from "lucide-react"
import { Card } from "@/components/ui/card"
import { ThemeToggle } from "@/components/theme-toggle"

export default function ProfileSection() {
  return (
    <section className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      <Card className="w-full max-w-xl overflow-hidden rounded-xl shadow-2xl">
        <div className="bg-gradient-to-br from-teal-700 to-teal-500 p-8 text-white dark:from-teal-800 dark:to-teal-600">
          <div className="flex flex-col md:flex-row items-center">
            <div className="flex-1 text-center md:text-left mb-6 md:mb-0 md:mr-6">
              <h1 className="text-3xl font-bold mb-1">John Smith</h1>
              <p className="text-lg mb-4">Photographer & Web Developer</p>
              <p className="text-sm leading-relaxed">
                Hi there! I'm John, a seasoned photographer and web developer passionate about capturing moments and
                crafting clean, dynamic websites. With 5 years of experience, I specialize in nature photography and web
                development using modern technologies. I thrive on creating visual stories and user-centric designs.
                Let's collaborate TOGETHER!
              </p>
            </div>
            <div className="flex-shrink-0">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-teal-400">
                <img src="/placeholder.svg?height=128&width=128" alt="Profile" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>

          <div className="flex justify-center md:justify-start space-x-6 mt-6">
            <a href="#" className="hover:text-teal-200 transition-colors" aria-label="LinkedIn">
              <Linkedin size={24} />
            </a>
            <a href="#" className="hover:text-teal-200 transition-colors" aria-label="GitHub">
              <Github size={24} />
            </a>
            <a href="#" className="hover:text-teal-200 transition-colors" aria-label="Resume">
              <FileText size={24} />
            </a>
            <a href="#" className="hover:text-teal-200 transition-colors" aria-label="Instagram">
              <Instagram size={24} />
            </a>
          </div>
        </div>
      </Card>
    </section>
  )
}
