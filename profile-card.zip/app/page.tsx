import ProfileSection from "@/components/profile-section"
import PortfolioSection from "@/components/portfolio-section"

// Sample data for the portfolio section
const samplePhotos = [
  {
    id: "1",
    type: "image",
    title: "Spring Flowers",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "2",
    type: "image",
    title: "Fire Hydrant",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "urban" }],
  },
  {
    id: "3",
    type: "image",
    title: "Green Leaves",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "4",
    type: "image",
    title: "Meteor Shower",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "night" }],
  },
  {
    id: "5",
    type: "image",
    title: "Dandelions",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "6",
    type: "image",
    title: "Red Flower",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "7",
    type: "video",
    title: "Water Splash",
    url: "/placeholder.mp4",
    thumbnailUrl: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "water" }],
  },
  {
    id: "8",
    type: "image",
    title: "Water Droplets",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "macro" }],
  },
  {
    id: "9",
    type: "video",
    title: "Nature Video",
    url: "/placeholder.mp4",
    thumbnailUrl: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "10",
    type: "image",
    title: "Pink Roses",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "flowers" }],
  },
  {
    id: "11",
    type: "image",
    title: "Green Plants",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "12",
    type: "image",
    title: "Sunset Street",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "urban" }],
  },
]

export default async function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <ProfileSection />
      <PortfolioSection initialItems={samplePhotos} />
    </main>
  )
}
