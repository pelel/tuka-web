import { ImageResponse } from "next/og"

export const runtime = "edge"
export const alt = "Photography Portfolio"
export const size = {
  width: 1200,
  height: 630,
}

export default async function Image() {
  // Sample photos for the OG image
  const photos = [
    "/placeholder.svg?height=400&width=600&text=Nature",
    "/placeholder.svg?height=400&width=600&text=Urban",
    "/placeholder.svg?height=400&width=600&text=Portrait",
    "/placeholder.svg?height=400&width=600&text=Landscape",
  ]

  return new ImageResponse(
    <div
      style={{
        background: "linear-gradient(to bottom right, #0f766e, #115e59)",
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        color: "white",
        padding: 40,
      }}
    >
      <div
        style={{
          display: "flex",
          fontSize: 60,
          fontWeight: 700,
          letterSpacing: -1,
          marginBottom: 40,
        }}
      >
        Photography Portfolio
      </div>

      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: 20,
          maxWidth: 1000,
        }}
      >
        {photos.map((photo, i) => (
          <div
            key={i}
            style={{
              width: 240,
              height: 240,
              borderRadius: 12,
              overflow: "hidden",
              border: "4px solid rgba(255,255,255,0.2)",
            }}
          >
            <img
              src={photo || "/placeholder.svg"}
              alt={`Sample photo ${i + 1}`}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
              }}
            />
          </div>
        ))}
      </div>
    </div>,
    { ...size },
  )
}
