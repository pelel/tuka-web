import { InfiniteGallery } from "@/components/portfolio/infinite-gallery"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

// Sample data for the tag page
const samplePhotos = [
  {
    id: "1",
    type: "image",
    title: "Spring Flowers",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "3",
    type: "image",
    title: "Green Leaves",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "5",
    type: "image",
    title: "Dandelions",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "6",
    type: "image",
    title: "Red Flower",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "9",
    type: "video",
    title: "Nature Video",
    url: "/placeholder.mp4",
    thumbnailUrl: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "11",
    type: "image",
    title: "Green Plants",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
]

export default function TagPage({ params }: { params: { tag: string } }) {
  const tag = params.tag

  // In a real app, you would filter photos by tag from your database
  const filteredPhotos = samplePhotos.filter((photo) =>
    photo.tags.some((t) => t.name.toLowerCase() === tag.toLowerCase()),
  )

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="outline" size="icon" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Tag: {tag}</h1>
      </div>

      <InfiniteGallery initialItems={filteredPhotos} viewMode="grid" tag={tag} />
    </div>
  )
}
