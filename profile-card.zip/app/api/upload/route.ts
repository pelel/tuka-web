import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/prisma"
import { put } from "@vercel/blob"
import { nanoid } from "nanoid"

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = session.user.id as string

    // Parse form data
    const formData = await request.formData()
    const file = formData.get("file") as File
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const tagsJson = formData.get("tags") as string
    const exifJson = formData.get("exif") as string

    if (!file || !title) {
      return NextResponse.json({ error: "File and title are required" }, { status: 400 })
    }

    // Parse tags and exif data
    const tags = tagsJson ? JSON.parse(tagsJson) : []
    const exifData = exifJson ? JSON.parse(exifJson) : null

    // Determine file type
    const fileType = file.type.startsWith("image/") ? "image" : "video"

    // Generate unique filename
    const uniqueId = nanoid()
    const extension = file.name.split(".").pop()
    const fileName = `${uniqueId}.${extension}`

    // Upload to Vercel Blob
    const { url } = await put(fileName, file, {
      access: "public",
    })

    // Generate thumbnail for videos (in a real app, you'd use a service like FFmpeg)
    let thumbnailUrl = null
    if (fileType === "video") {
      // For demo purposes, we're using a placeholder
      thumbnailUrl = `/placeholder.svg?height=400&width=600&text=${encodeURIComponent(title)}`
    }

    // Create photo record in database
    const photo = await prisma.photo.create({
      data: {
        title,
        description: description || null,
        url,
        thumbnailUrl,
        type: fileType,
        userId,
        // Create tags if they don't exist
        tags: {
          connectOrCreate: tags.map((tag: string) => ({
            where: { name: tag },
            create: { name: tag },
          })),
        },
        // Create EXIF data if available
        ...(exifData && {
          exif: {
            create: {
              make: exifData.make,
              model: exifData.model,
              focalLength: exifData.focalLength,
              fNumber: exifData.fNumber,
              exposureTime: exifData.exposureTime,
              iso: exifData.iso,
              width: exifData.width,
              height: exifData.height,
              takenAt: exifData.takenAt,
              latitude: exifData.latitude,
              longitude: exifData.longitude,
            },
          },
        }),
      },
    })

    return NextResponse.json({ success: true, photo }, { status: 201 })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "Failed to upload file" }, { status: 500 })
  }
}
