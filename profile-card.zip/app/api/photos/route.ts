import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    // Get query parameters
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "12")
    const tag = searchParams.get("tag")
    const search = searchParams.get("search")

    // Calculate pagination
    const skip = (page - 1) * limit

    // Build query
    const where: any = {}

    // Filter by tag if provided
    if (tag) {
      where.tags = {
        some: {
          name: tag,
        },
      }
    }

    // Search by title or description if provided
    if (search) {
      where.OR = [
        {
          title: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          description: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          tags: {
            some: {
              name: {
                contains: search,
                mode: "insensitive",
              },
            },
          },
        },
      ]
    }

    // Get photos
    const photos = await prisma.photo.findMany({
      where,
      include: {
        tags: {
          select: {
            name: true,
          },
        },
        exif: true,
      },
      orderBy: {
        createdAt: "desc",
      },
      skip,
      take: limit,
    })

    // Get total count for pagination
    const totalCount = await prisma.photo.count({ where })

    return NextResponse.json({
      photos,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
        hasMore: skip + photos.length < totalCount,
      },
    })
  } catch (error) {
    console.error("Error fetching photos:", error)
    return NextResponse.json({ error: "Failed to fetch photos" }, { status: 500 })
  }
}
