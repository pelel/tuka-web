import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")

    if (!query || query.length < 2) {
      return NextResponse.json({ photos: [], tags: [] })
    }

    // Search photos
    const photos = await prisma.photo.findMany({
      where: {
        OR: [
          {
            title: {
              contains: query,
              mode: "insensitive",
            },
          },
          {
            description: {
              contains: query,
              mode: "insensitive",
            },
          },
          {
            tags: {
              some: {
                name: {
                  contains: query,
                  mode: "insensitive",
                },
              },
            },
          },
        ],
      },
      select: {
        id: true,
        title: true,
        type: true,
      },
      take: 5,
    })

    // Search tags
    const tags = await prisma.tag.findMany({
      where: {
        name: {
          contains: query,
          mode: "insensitive",
        },
      },
      select: {
        name: true,
        _count: {
          select: {
            photos: true,
          },
        },
      },
      take: 5,
    })

    // Format tags with count
    const formattedTags = tags.map((tag) => ({
      name: tag.name,
      count: tag._count.photos,
    }))

    return NextResponse.json({
      photos,
      tags: formattedTags,
    })
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json({ error: "Search failed" }, { status: 500 })
  }
}
