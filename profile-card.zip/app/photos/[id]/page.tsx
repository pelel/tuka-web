import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, Calendar, Camera, MapPin, Tag } from "lucide-react"

// Sample data for the photo detail page
const samplePhotos = [
  {
    id: "1",
    type: "image",
    title: "Spring Flowers",
    description: "Beautiful spring flowers blooming in the garden.",
    url: "/placeholder.svg?height=800&width=1200",
    createdAt: "2025-04-15T10:30:00Z",
    tags: [{ name: "nature" }, { name: "flowers" }, { name: "spring" }],
    exif: {
      make: "FUJIFILM",
      model: "X-T5",
      focalLength: 35,
      fNumber: 2.8,
      exposureTime: "1/125",
      iso: 400,
      takenAt: "2025-04-15T10:30:00Z",
    },
    location: "Central Park, New York",
  },
  {
    id: "2",
    type: "image",
    title: "Fire Hydrant",
    description: "A bright red fire hydrant on a city street.",
    url: "/placeholder.svg?height=800&width=1200",
    createdAt: "2025-04-10T14:45:00Z",
    tags: [{ name: "urban" }, { name: "street" }, { name: "red" }],
    exif: {
      make: "FUJIFILM",
      model: "X-T5",
      focalLength: 23,
      fNumber: 4,
      exposureTime: "1/250",
      iso: 200,
      takenAt: "2025-04-10T14:45:00Z",
    },
    location: "Brooklyn, New York",
  },
]

export default function PhotoDetailPage({ params }: { params: { id: string } }) {
  // In a real app, you would fetch the photo by ID from your database
  const photo = samplePhotos.find((p) => p.id === params.id) || samplePhotos[0]

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="outline" size="icon" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">{photo.title}</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="rounded-lg overflow-hidden bg-black">
            {photo.type === "image" ? (
              <img src={photo.url || "/placeholder.svg"} alt={photo.title} className="w-full h-auto" />
            ) : (
              <video src={photo.url} controls className="w-full h-auto">
                Your browser does not support the video tag.
              </video>
            )}
          </div>

          <div className="mt-6">
            <h2 className="text-2xl font-semibold mb-2">Description</h2>
            <p className="text-muted-foreground">{photo.description}</p>
          </div>

          <div className="mt-6">
            <h2 className="text-2xl font-semibold mb-2">Tags</h2>
            <div className="flex flex-wrap gap-2">
              {photo.tags.map((tag) => (
                <Badge key={tag.name} variant="secondary" asChild>
                  <Link href={`/tags/${tag.name}`}>{tag.name}</Link>
                </Badge>
              ))}
            </div>
          </div>
        </div>

        <div>
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-4">Details</h2>

              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <Calendar className="h-5 w-5 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Date Taken</p>
                    <p className="text-sm text-muted-foreground">
                      {photo.exif?.takenAt ? formatDate(photo.exif.takenAt) : formatDate(photo.createdAt)}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Camera className="h-5 w-5 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Camera</p>
                    <p className="text-sm text-muted-foreground">
                      {photo.exif?.make} {photo.exif?.model}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Tag className="h-5 w-5 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Settings</p>
                    <p className="text-sm text-muted-foreground">
                      {photo.exif?.focalLength}mm, f/{photo.exif?.fNumber}, {photo.exif?.exposureTime}s, ISO{" "}
                      {photo.exif?.iso}
                    </p>
                  </div>
                </div>

                {photo.location && (
                  <div className="flex items-start gap-2">
                    <MapPin className="h-5 w-5 mt-0.5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Location</p>
                      <p className="text-sm text-muted-foreground">{photo.location}</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-4">Similar Photos</h2>
            <div className="grid grid-cols-2 gap-2">
              {samplePhotos
                .filter((p) => p.id !== photo.id)
                .slice(0, 4)
                .map((p) => (
                  <Link key={p.id} href={`/photos/${p.id}`} className="rounded-md overflow-hidden">
                    <img
                      src={p.url || "/placeholder.svg"}
                      alt={p.title}
                      className="w-full h-auto aspect-square object-cover hover:opacity-80 transition-opacity"
                    />
                  </Link>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
