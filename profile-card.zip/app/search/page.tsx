"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { InfiniteGallery } from "@/components/portfolio/infinite-gallery"
import { SearchIcon } from "lucide-react"

// Sample data for the search page
const samplePhotos = [
  {
    id: "1",
    type: "image",
    title: "Spring Flowers",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "2",
    type: "image",
    title: "Fire Hydrant",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "urban" }],
  },
  {
    id: "3",
    type: "image",
    title: "Green Leaves",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  // Add more sample photos here
]

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [mediaType, setMediaType] = useState("all")
  const [sortBy, setSortBy] = useState("newest")
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [searchResults, setSearchResults] = useState(samplePhotos)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    // Filter photos based on search criteria
    let results = [...samplePhotos]

    // Filter by search query
    if (searchQuery) {
      results = results.filter((photo) => photo.title.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by media type
    if (mediaType !== "all") {
      results = results.filter((photo) => photo.type === mediaType)
    }

    // Filter by tags
    if (selectedTags.length > 0) {
      results = results.filter((photo) => photo.tags.some((tag) => selectedTags.includes(tag.name)))
    }

    // Sort results
    if (sortBy === "newest") {
      // In a real app, you would sort by date
      results = [...results]
    } else if (sortBy === "oldest") {
      // In a real app, you would sort by date
      results = [...results].reverse()
    } else if (sortBy === "title") {
      results = [...results].sort((a, b) => a.title.localeCompare(b.title))
    }

    setSearchResults(results)
  }

  const handleTagToggle = (tag: string) => {
    setSelectedTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]))
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Advanced Search</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="pt-6">
              <form onSubmit={handleSearch} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="search-query">Search</Label>
                  <div className="flex gap-2">
                    <Input
                      id="search-query"
                      placeholder="Search photos..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <Button type="submit" size="icon">
                      <SearchIcon className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Media Type</Label>
                  <RadioGroup value={mediaType} onValueChange={setMediaType}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="all" id="all" />
                      <Label htmlFor="all">All</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="image" id="image" />
                      <Label htmlFor="image">Images</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="video" id="video" />
                      <Label htmlFor="video">Videos</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sort-by">Sort By</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger id="sort-by">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest First</SelectItem>
                      <SelectItem value="oldest">Oldest First</SelectItem>
                      <SelectItem value="title">Title (A-Z)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="space-y-2">
                    {["nature", "urban", "portrait", "landscape", "macro", "night"].map((tag) => (
                      <div key={tag} className="flex items-center space-x-2">
                        <Checkbox
                          id={`tag-${tag}`}
                          checked={selectedTags.includes(tag)}
                          onCheckedChange={() => handleTagToggle(tag)}
                        />
                        <Label htmlFor={`tag-${tag}`}>{tag}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Search
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <h2 className="text-2xl font-semibold mb-4">Search Results</h2>
          {searchResults.length > 0 ? (
            <InfiniteGallery initialItems={searchResults} viewMode="grid" />
          ) : (
            <div className="text-center py-12">
              <p className="text-xl font-medium">No results found</p>
              <p className="text-muted-foreground mt-2">Try adjusting your search criteria</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
