import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Upload, Filter } from "lucide-react"
import { InfiniteGallery } from "@/components/portfolio/infinite-gallery"

// Sample data for the photos page
const samplePhotos = [
  {
    id: "1",
    type: "image",
    title: "Spring Flowers",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  {
    id: "2",
    type: "image",
    title: "Fire Hydrant",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "urban" }],
  },
  {
    id: "3",
    type: "image",
    title: "Green Leaves",
    url: "/placeholder.svg?height=400&width=600",
    tags: [{ name: "nature" }],
  },
  // Add more sample photos here
]

export default async function PhotosPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">My Photos</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button asChild>
            <Link href="/upload">
              <Upload className="mr-2 h-4 w-4" />
              Upload
            </Link>
          </Button>
        </div>
      </div>

      <InfiniteGallery initialItems={samplePhotos} viewMode="grid" />
    </div>
  )
}
