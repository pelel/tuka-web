import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Upload, Settings } from "lucide-react"
import { MediaCard } from "@/components/media-card"

// Sample data for the dashboard
const samplePhotos = [
  { id: "1", type: "image", title: "Spring Flowers", url: "/placeholder.svg?height=400&width=600" },
  { id: "2", type: "image", title: "Fire Hydrant", url: "/placeholder.svg?height=400&width=600" },
  { id: "3", type: "image", title: "Green Leaves", url: "/placeholder.svg?height=400&width=600" },
  { id: "4", type: "image", title: "Meteor Shower", url: "/placeholder.svg?height=400&width=600" },
  { id: "5", type: "image", title: "Dandelions", url: "/placeholder.svg?height=400&width=600" },
  { id: "6", type: "image", title: "Red Flower", url: "/placeholder.svg?height=400&width=600" },
  {
    id: "7",
    type: "video",
    title: "Water Splash",
    url: "/placeholder.mp4",
    thumbnailUrl: "/placeholder.svg?height=400&width=600",
  },
  { id: "8", type: "image", title: "Water Droplets", url: "/placeholder.svg?height=400&width=600" },
]

const sampleTags = [
  { name: "nature", count: 8 },
  { name: "urban", count: 3 },
  { name: "portrait", count: 2 },
  { name: "macro", count: 4 },
  { name: "night", count: 2 },
]

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/upload">
              <Upload className="mr-2 h-4 w-4" />
              Upload
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/settings">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Recent Uploads</h2>
              <Button variant="link" asChild>
                <Link href="/dashboard/photos">View All</Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {samplePhotos.map((photo) => (
                <MediaCard
                  key={photo.id}
                  item={{
                    id: Number.parseInt(photo.id),
                    type: photo.type as "image" | "video",
                    src: photo.url,
                    thumbnail: photo.thumbnailUrl,
                    title: photo.title,
                  }}
                  viewMode="grid"
                />
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Popular Tags</h2>
              <Button variant="link" asChild>
                <Link href="/dashboard/tags">Manage Tags</Link>
              </Button>
            </div>

            <div className="space-y-2">
              {sampleTags.map((tag) => (
                <div key={tag.name} className="flex justify-between items-center p-2 hover:bg-muted rounded-md">
                  <span className="font-medium">{tag.name}</span>
                  <span className="text-sm text-muted-foreground">{tag.count} photos</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card rounded-lg p-6 shadow-sm mt-6">
            <h2 className="text-xl font-semibold mb-4">Stats</h2>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Photos</span>
                <span className="font-medium">24</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Videos</span>
                <span className="font-medium">3</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Tags</span>
                <span className="font-medium">12</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Storage Used</span>
                <span className="font-medium">128 MB</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
