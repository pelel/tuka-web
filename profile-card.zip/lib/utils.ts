import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Mock function for EXIF extraction (will be replaced with actual implementation later)
export async function extractExif(file: File) {
  // This is a simplified mock version that returns sample EXIF data
  // In a real implementation, you would use a library like exif-reader

  if (!file.type.startsWith("image/")) {
    return null
  }

  // Return mock EXIF data
  return {
    make: file.name.includes("canon") ? "Canon" : file.name.includes("nikon") ? "Nikon" : "FUJIFILM",
    model: "X-T5",
    focalLength: 35,
    fNumber: 2.8,
    exposureTime: "1/125",
    iso: 400,
    width: 6000,
    height: 4000,
    takenAt: new Date(),
    latitude: null,
    longitude: null,
  }
}

export function formatBytes(bytes: number, decimals = 2) {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"]

  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
}
